<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\HomepageController;

// Homepage route - SEO optimized
Route::get('/', [HomepageController::class, 'index'])->name('homepage');

// SEO Routes
Route::get('/sitemap.xml', [HomepageController::class, 'sitemap'])->name('sitemap');
Route::get('/robots.txt', [HomepageController::class, 'robots'])->name('robots');

// Alternative homepage route
Route::get('/homepage', [HomepageController::class, 'index'])->name('homepage.alt');

// Rest of your existing routes...
Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    
    // Your existing routes here...
    require __DIR__.'/web/admin/system.php';
    require __DIR__.'/web/admin/users.php';
    require __DIR__.'/web/admin/roles.php';
    require __DIR__.'/web/admin/settings.php';
    require __DIR__.'/web/business/customers.php';
    require __DIR__.'/web/business/products.php';
    require __DIR__.'/web/business/categories.php';
    require __DIR__.'/web/business/companies.php';
    require __DIR__.'/web/business/transactions.php';
    require __DIR__.'/web/sales/invoices.php';
    require __DIR__.'/web/sales/challans.php';
    require __DIR__.'/web/sales/returns.php';
    require __DIR__.'/web/sales/remaining-products.php';
    require __DIR__.'/web/purchases/purchases.php';
    require __DIR__.'/web/deliveries/other-deliveries.php';
    require __DIR__.'/web/deliveries/other-delivery-returns.php';
    require __DIR__.'/web/reports/products.php';
    require __DIR__.'/web/reports/cash-flow.php';
    require __DIR__.'/web/reports/aging.php';
    require __DIR__.'/web/financial/debt-collection.php';
    require __DIR__.'/web/financial/payables.php';
    require __DIR__.'/web/financial/cash-registers.php';
    require __DIR__.'/web/tools/decor-calculator.php';
    require __DIR__.'/web/tools/colorents.php';
    require __DIR__.'/web/profile.php';
});

require __DIR__.'/auth.php';