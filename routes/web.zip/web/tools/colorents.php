<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ColorentManagementController;

Route::prefix('colorents')->name('colorents.')->group(function () {
    Route::get('/management', [ColorentManagementController::class, 'index'])->name('management');
    Route::post('/{id}/update-stock', [ColorentManagementController::class, 'updateStock'])->name('updateStock');
    Route::post('/{id}/update-price', [ColorentManagementController::class, 'updatePrice'])->name('updatePrice');
});
