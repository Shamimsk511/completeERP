<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductReportController;

Route::prefix('reports')->name('reports.')->group(function () {
    Route::get('/products', [ProductReportController::class, 'index'])->name('products.index');
    Route::get('/products/sales', [ProductReportController::class, 'salesReport'])->name('products.sales');
    Route::get('/products/returns', [ProductReportController::class, 'returnsReport'])->name('products.returns');
    Route::get('/products/purchases', [ProductReportController::class, 'purchasesReport'])->name('products.purchases');
    Route::get('/products/other-deliveries', [ProductReportController::class, 'otherDeliveriesReport'])->name('products.other-deliveries');
    Route::get('/products/consolidated', [ProductReportController::class, 'consolidatedReport'])->name('products.consolidated');
    
    // Detail routes for AJAX requests
    Route::get('/products/sales/details', [ProductReportController::class, 'getProductSaleDetails'])->name('products.sales.details');
    Route::get('/products/returns/details', [ProductReportController::class, 'getProductReturnDetails'])->name('products.returns.details');
    Route::get('/products/purchases/details', [ProductReportController::class, 'getProductPurchaseDetails'])->name('products.purchases.details');
    Route::get('/products/other-deliveries/details', [ProductReportController::class, 'getProductDeliveryDetails'])->name('products.other-deliveries.details');
});
