<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;

// Product data routes
Route::get('products/get-products', [ProductController::class, 'getProducts'])->name('products.getProducts');

// Product imports
Route::post('products/import', [ProductController::class, 'import'])->name('products.import');
Route::get('products/template/download', [ProductController::class, 'downloadTemplate'])->name('products.template.download');

// Reports main page
Route::get('/products/reports', [ProductController::class, 'reportsIndex'])->name('products.reports.index');

// Stock Report routes
Route::get('/products/reports/stock-data', [ProductController::class, 'getStockReport'])->name('products.reports.stock');
Route::get('/products/reports/stock-export', [ProductController::class, 'exportStockReport'])->name('products.reports.stock.export');

// Stock Value Report routes
Route::get('/products/reports/value-data', [ProductController::class, 'getStockValueReport'])->name('products.reports.value');
Route::get('/products/reports/value-export', [ProductController::class, 'exportStockValueReport'])->name('products.reports.value.export');

Route::resource('products', ProductController::class);
