<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ChallanController;

Route::resource('challans', ChallanController::class);

// Challan printing and status management
Route::get('challan-print/{challan}', [ChallanController::class, 'print'])->name('challans.print');
Route::post('challans/{challan}/update-status', [ChallanController::class, 'updateStatus'])->name('challans.update-status');
Route::get('challans/{challan}/status/{status}', [ChallanController::class, 'updateStatus'])->name('challans.updateStatus');

// Invoice items for challans
Route::get('get-invoice-items/{invoice}', [ChallanController::class, 'getInvoiceItems'])->name('get-invoice-items');
