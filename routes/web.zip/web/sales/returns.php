<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductReturnController;

Route::resource('returns', ProductReturnController::class);

// Return printing
Route::get('returns/{return}/print', [ProductReturnController::class, 'print'])->name('returns.print');

// Customer and invoice data for returns
Route::get('customer-invoices/{customerId}', [ProductReturnController::class, 'getInvoicesByCustomer']);
Route::get('invoice-items/{invoiceId}', [ProductReturnController::class, 'getInvoiceItems']);
