<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SystemManagementController;

Route::prefix('system')->name('system.')->middleware('can:update,App\Models\User')->group(function () {
    Route::get('/', [SystemManagementController::class, 'index'])->name('index');
    
    // Cache Management
    Route::post('/cache/clear', [SystemManagementController::class, 'clearCache'])->name('cache.clear');
    Route::post('/cache/optimize', [SystemManagementController::class, 'optimizeCache'])->name('cache.optimize');
    
    // Database Backup & Restore
    Route::post('/backup/create', [SystemManagementController::class, 'createBackup'])->name('backup.create');
    Route::get('/backup/download/{filename}', [SystemManagementController::class, 'downloadBackup'])->name('backup.download');
    Route::delete('/backup/delete/{filename}', [SystemManagementController::class, 'deleteBackup'])->name('backup.delete');
    Route::post('/backup/restore', [SystemManagementController::class, 'restoreBackup'])->name('backup.restore');
});
