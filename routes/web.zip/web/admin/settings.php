<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BusinessSettingController;

Route::prefix('business-settings')->name('business-settings.')->group(function () {
    Route::get('/', [BusinessSettingController::class, 'index'])->name('index');
    Route::put('/', [BusinessSettingController::class, 'update'])->name('update');
});
