<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CashRegisterController;

Route::get('cash-registers', [CashRegisterController::class, 'index'])->name('cash-registers.index');
Route::get('cash-registers/open', [CashRegisterController::class, 'open'])->name('cash-registers.open');
Route::post('cash-registers', [CashRegisterController::class, 'store'])->name('cash-registers.store');
Route::get('cash-registers/{cashRegister}', [CashRegisterController::class, 'show'])->name('cash-registers.show');
Route::post('cash-registers/{cashRegister}/add-transaction', [CashRegisterController::class, 'addTransaction'])->name('cash-registers.add-transaction');
Route::get('cash-registers/{cashRegister}/close', [CashRegisterController::class, 'close'])->name('cash-registers.close');
Route::post('cash-registers/{cashRegister}/process-close', [CashRegisterController::class, 'processClose'])->name('cash-registers.process-close');
Route::get('cash-registers-report', [CashRegisterController::class, 'report'])->name('cash-registers.report');
Route::post('cash-registers/{cashRegister}/verify-pin', [CashRegisterController::class, 'verifyPin'])->name('cash-registers.verify-pin');
Route::post('cash-registers/{cashRegister}/suspend', [CashRegisterController::class, 'suspend'])->name('cash-registers.suspend');
Route::post('cash-registers/{cashRegister}/resume', [CashRegisterController::class, 'resume'])->name('cash-registers.resume');
Route::post('cash-register-transactions/{transaction}/void', [CashRegisterController::class, 'voidTransaction'])->name('cash-register-transactions.void');
